package com.lms.lms.services;
import org.springframework.transaction.annotation.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lms.lms.entities.BorrowingRecord;
import com.lms.lms.repositories.BookRepository;
import com.lms.lms.repositories.BorrowingRecordRepository;
import com.lms.lms.repositories.PatronRepository;

import java.util.Optional;

@Service
public class BorrowingRecordService {

    @Autowired
    private BorrowingRecordRepository borrowingRecordRepository;

    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private PatronRepository patronRepository;

    @Transactional
    public Optional<BorrowingRecord> borrowBook(Long bookId, Long patronId) {
        return bookRepository.findById(bookId).flatMap(book ->
            patronRepository.findById(patronId).map(patron -> {
                BorrowingRecord record = new BorrowingRecord();
                record.setBook(book);
                record.setPatron(patron);
                record.setBorrowDate(new java.util.Date());
                return borrowingRecordRepository.save(record);
            })
        );
    }

    @Transactional
    public boolean returnBook(Long bookId, Long patronId) {
        Optional<BorrowingRecord> record = borrowingRecordRepository.findByBookIdAndPatronId(bookId, patronId);
        if (record.isPresent()) {
            BorrowingRecord borrowingRecord = record.get();
            borrowingRecord.setReturnDate(new java.util.Date());
            borrowingRecordRepository.save(borrowingRecord);
            return true;
        }
        return false;
    }
}
