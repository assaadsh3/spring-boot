package com.lms.lms.services;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.lms.lms.entities.Book;
import com.lms.lms.repositories.BookRepository;
import java.util.List;
import java.util.Optional;
@Service
public class BookService {
    @Autowired
    private BookRepository bookRepository;
    @Cacheable("books")
    public List<Book> findAll() {
        return bookRepository.findAll();
    }
    @Cacheable(value = "book", key = "#id")
    public Optional<Book> findById(Long id) {
        return bookRepository.findById(id);
    }
    @Transactional
    @CacheEvict(value = "books", allEntries = true)
    public Book save(Book book) {
        return bookRepository.save(book);
    }
    @Transactional
    @CacheEvict(value = {"books", "book"}, key = "#id")
    public Optional<Book> update(Long id, Book bookDetails) {
        return bookRepository.findById(id).map(book -> {
            book.setTitle(bookDetails.getTitle());
            book.setAuthor(bookDetails.getAuthor());
            book.setIsbn(bookDetails.getIsbn());
            book.setPublicationYear(bookDetails.getPublicationYear());
            return bookRepository.save(book);
        });
    }
    @Transactional
    public boolean delete(Long id) {
        if (bookRepository.existsById(id)) {
            bookRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
