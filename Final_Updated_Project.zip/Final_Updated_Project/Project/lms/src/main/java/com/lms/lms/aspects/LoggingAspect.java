
package com.lms.lms.aspects;

import org.aspectj.lang.annotation.*;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.springframework.stereotype.Component;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.AfterReturning;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Aspect
@Component
public class LoggingAspect {

    private static final Logger logger = LoggerFactory.getLogger(LoggingAspect.class);

    @Before("execution(* com.lms.lms.services.*.*(..))")
    public void logBeforeMethod() {
        logger.info("Method execution started");
    }

    @AfterReturning("execution(* com.lms.lms.services.*.*(..))")
    public void logAfterReturningMethod() {
        logger.info("Method execution finished successfully");
    }

    @AfterThrowing(pointcut = "execution(* com.lms.lms.services.*.*(..))", throwing = "ex")
    public void logAfterThrowingMethod(Exception ex) {
        logger.error("An exception occurred: " + ex.getMessage(), ex);
    }

    @Around("execution(* com.lms.lms.services.*.*(..))")
    public Object logExecutionTime(ProceedingJoinPoint joinPoint) throws Throwable {
        long startTime = System.currentTimeMillis();
        Object proceed = joinPoint.proceed();
        long executionTime = System.currentTimeMillis() - startTime;
        logger.info(joinPoint.getSignature() + " executed in " + executionTime + "ms");
        return proceed;
    }
}
