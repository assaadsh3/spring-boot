package com.lms.lms.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lms.lms.entities.Patron;

public interface PatronRepository extends JpaRepository<Patron, Long> {
    // Custom query methods (if any) can be added here
}
