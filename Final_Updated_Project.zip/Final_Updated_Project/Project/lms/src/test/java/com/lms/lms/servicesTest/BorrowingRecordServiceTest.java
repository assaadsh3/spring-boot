package com.lms.lms.servicesTest;

import com.lms.lms.entities.Book;
import com.lms.lms.entities.BorrowingRecord;
import com.lms.lms.entities.Patron;
import com.lms.lms.repositories.BookRepository;
import com.lms.lms.repositories.BorrowingRecordRepository;
import com.lms.lms.repositories.PatronRepository;
import com.lms.lms.services.BorrowingRecordService;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;
import java.util.Date;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

public class BorrowingRecordServiceTest {

    @Mock
    private BorrowingRecordRepository borrowingRecordRepository;

    @Mock
    private BookRepository bookRepository;

    @Mock
    private PatronRepository patronRepository;

    @InjectMocks
    private BorrowingRecordService borrowingRecordService;

    public BorrowingRecordServiceTest() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testBorrowBook() {
        // Arrange
        Book book = new Book();
        book.setId(1L);
        Patron patron = new Patron();
        patron.setId(1L);
        BorrowingRecord borrowingRecord = new BorrowingRecord();
        borrowingRecord.setBook(book);
        borrowingRecord.setPatron(patron);
        borrowingRecord.setBorrowDate(new Date());

        when(bookRepository.findById(1L)).thenReturn(Optional.of(book));
        when(patronRepository.findById(1L)).thenReturn(Optional.of(patron));
        when(borrowingRecordRepository.save(any(BorrowingRecord.class))).thenReturn(borrowingRecord);

        // Act
        Optional<BorrowingRecord> result = borrowingRecordService.borrowBook(1L, 1L);

        // Assert
        assertThat(result).isPresent();
        assertThat(result.get().getBook()).isEqualTo(book);
        assertThat(result.get().getPatron()).isEqualTo(patron);
        verify(bookRepository, times(1)).findById(1L);
        verify(patronRepository, times(1)).findById(1L);
        verify(borrowingRecordRepository, times(1)).save(any(BorrowingRecord.class));
    }

    @Test
    public void testReturnBook() {
        // Arrange
        Book book = new Book();
        book.setId(1L);
        Patron patron = new Patron();
        patron.setId(1L);
        BorrowingRecord borrowingRecord = new BorrowingRecord();
        borrowingRecord.setBook(book);
        borrowingRecord.setPatron(patron);

        when(borrowingRecordRepository.findByBookIdAndPatronId(1L, 1L)).thenReturn(Optional.of(borrowingRecord));

        // Act
        boolean result = borrowingRecordService.returnBook(1L, 1L);

        // Assert
        assertThat(result).isTrue();
        assertThat(borrowingRecord.getReturnDate()).isNotNull();
        verify(borrowingRecordRepository, times(1)).findByBookIdAndPatronId(1L, 1L);
        verify(borrowingRecordRepository, times(1)).save(borrowingRecord);
    }
}
