package com.lms.lms.servicesTest;

import com.lms.lms.entities.Patron;
import com.lms.lms.repositories.PatronRepository;
import com.lms.lms.services.PatronService;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

public class PatronServiceTest {

    @Mock
    private PatronRepository patronRepository;

    @InjectMocks
    private PatronService patronService;

    public PatronServiceTest() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testFindAll() {
        // Arrange
        Patron patron1 = new Patron();
        patron1.setName("John Doe");
        Patron patron2 = new Patron();
        patron2.setName("Jane Doe");
        List<Patron> patrons = Arrays.asList(patron1, patron2);

        when(patronRepository.findAll()).thenReturn(patrons);

        // Act
        List<Patron> result = patronService.findAll();

        // Assert
        assertThat(result).hasSize(2).contains(patron1, patron2);
        verify(patronRepository, times(1)).findAll();
    }

    @Test
    public void testFindById() {
        // Arrange
        Patron patron = new Patron();
        patron.setId(1L);
        patron.setName("John Doe");

        when(patronRepository.findById(1L)).thenReturn(Optional.of(patron));

        // Act
        Optional<Patron> result = patronService.findById(1L);

        // Assert
        assertThat(result).isPresent();
        assertThat(result.get().getName()).isEqualTo("John Doe");
        verify(patronRepository, times(1)).findById(1L);
    }

    @Test
    public void testSave() {
        // Arrange
        Patron patron = new Patron();
        patron.setName("John Doe");

        when(patronRepository.save(patron)).thenReturn(patron);

        // Act
        Patron result = patronService.save(patron);

        // Assert
        assertThat(result.getName()).isEqualTo("John Doe");
        verify(patronRepository, times(1)).save(patron);
    }

    @Test
    public void testUpdate() {
        // Arrange
        Patron existingPatron = new Patron();
        existingPatron.setId(1L);
        existingPatron.setName("Old Name");

        Patron newPatronDetails = new Patron();
        newPatronDetails.setName("New Name");

        when(patronRepository.findById(1L)).thenReturn(Optional.of(existingPatron));
        when(patronRepository.save(existingPatron)).thenReturn(existingPatron);

        // Act
        Optional<Patron> result = patronService.update(1L, newPatronDetails);

        // Assert
        assertThat(result).isPresent();
        assertThat(result.get().getName()).isEqualTo("New Name");
        verify(patronRepository, times(1)).findById(1L);
        verify(patronRepository, times(1)).save(existingPatron);
    }

    @Test
    public void testDelete() {
        // Arrange
        when(patronRepository.existsById(1L)).thenReturn(true);

        // Act
        boolean result = patronService.delete(1L);

        // Assert
        assertThat(result).isTrue();
        verify(patronRepository, times(1)).existsById(1L);
        verify(patronRepository, times(1)).deleteById(1L);
    }
}
