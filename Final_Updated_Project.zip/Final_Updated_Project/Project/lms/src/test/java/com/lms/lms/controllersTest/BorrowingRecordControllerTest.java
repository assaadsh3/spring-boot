package com.lms.lms.controllersTest;

import com.lms.lms.controllers.BorrowingRecordController;
import com.lms.lms.entities.BorrowingRecord;
import com.lms.lms.services.BorrowingRecordService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.anyLong;

import java.util.Optional;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(BorrowingRecordController.class)
public class BorrowingRecordControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private BorrowingRecordService borrowingRecordService;

    @Test
    public void shouldBorrowBook() throws Exception {
        BorrowingRecord record = new BorrowingRecord();
        record.setId(1L);

        Mockito.when(borrowingRecordService.borrowBook(1L, 1L)).thenReturn(Optional.of(record));

        mockMvc.perform(post("/api/borrow/1/patron/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id", is(1)));
    }

    @Test
    public void shouldReturnBook() throws Exception {
        Mockito.when(borrowingRecordService.returnBook(1L, 1L)).thenReturn(true);

        mockMvc.perform(put("/api/borrow/return/1/patron/1"))
                .andExpect(status().isOk());
    }

    @Test
    public void shouldReturnBadRequestWhenBookIdIsInvalid() throws Exception {
        Mockito.when(borrowingRecordService.borrowBook(anyLong(), anyLong())).thenReturn(Optional.empty());

        mockMvc.perform(post("/api/borrow/999/patron/1"))
                .andExpect(status().isBadRequest());
    }

    @Test
    public void shouldReturnBadRequestWhenReturningInvalidRecord() throws Exception {
        Mockito.when(borrowingRecordService.returnBook(anyLong(), anyLong())).thenReturn(false);

        mockMvc.perform(put("/api/borrow/return/1/patron/999"))
                .andExpect(status().isBadRequest());
    }
}
