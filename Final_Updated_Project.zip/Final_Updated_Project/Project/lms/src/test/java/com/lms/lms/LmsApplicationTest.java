package com.lms.lms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class LmsApplicationTest {

    @Test
    public void contextLoads() {
        // This method will check if the Spring application context loads successfully.
    }
}
