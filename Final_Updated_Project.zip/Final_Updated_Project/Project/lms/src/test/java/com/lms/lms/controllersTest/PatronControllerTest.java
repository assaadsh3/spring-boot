package com.lms.lms.controllersTest;

import com.lms.lms.controllers.PatronController;
import com.lms.lms.entities.Patron;
import com.lms.lms.services.PatronService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.Optional;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.hamcrest.Matchers.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;

@WebMvcTest(PatronController.class)
public class PatronControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private PatronService patronService;

    @Test
    public void shouldReturnListOfPatrons() throws Exception {
        Patron patron1 = new Patron();
        patron1.setId(1L);
        patron1.setName("John Doe");

        Patron patron2 = new Patron();
        patron2.setId(2L);
        patron2.setName("Jane Doe");

        Mockito.when(patronService.findAll()).thenReturn(Arrays.asList(patron1, patron2));

        mockMvc.perform(get("/api/patrons"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].name", is("John Doe")))
                .andExpect(jsonPath("$[1].name", is("Jane Doe")));
    }

    @Test
    public void shouldReturnPatronById() throws Exception {
        Patron patron = new Patron();
        patron.setId(1L);
        patron.setName("John Doe");

        Mockito.when(patronService.findById(1L)).thenReturn(Optional.of(patron));

        mockMvc.perform(get("/api/patrons/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name", is("John Doe")));
    }

    @Test
    public void shouldCreatePatron() throws Exception {
        Patron patron = new Patron();
        patron.setId(1L);
        patron.setName("John Doe");

        Mockito.when(patronService.save(any(Patron.class))).thenReturn(patron);

        mockMvc.perform(post("/api/patrons")
                .contentType("application/json")
                .content("{\"name\":\"John Doe\",\"email\":\"john@example.com\",\"phoneNumber\":\"1234567890\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name", is("John Doe")));
    }

    @Test
    public void shouldUpdatePatron() throws Exception {
        Patron patron = new Patron();
        patron.setId(1L);
        patron.setName("Updated Name");

        Mockito.when(patronService.update(eq(1L), any(Patron.class))).thenReturn(Optional.of(patron));

        mockMvc.perform(put("/api/patrons/1")
                .contentType("application/json")
                .content("{\"name\":\"Updated Name\",\"email\":\"updated@example.com\",\"phoneNumber\":\"0987654321\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name", is("Updated Name")));
    }

    @Test
    public void shouldDeletePatron() throws Exception {
        Mockito.when(patronService.delete(1L)).thenReturn(true);

        mockMvc.perform(delete("/api/patrons/1"))
                .andExpect(status().isOk());
    }
}
