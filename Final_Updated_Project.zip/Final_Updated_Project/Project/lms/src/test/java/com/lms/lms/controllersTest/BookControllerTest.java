package com.lms.lms.controllersTest;

import com.lms.lms.controllers.BookController;
import com.lms.lms.entities.Book;
import com.lms.lms.services.BookService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.Optional;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.hamcrest.Matchers.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;

@WebMvcTest(BookController.class)
@AutoConfigureMockMvc(addFilters = false)
public class BookControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private BookService bookService;

    @Test
    public void shouldReturnListOfBooks() throws Exception {
        Book book1 = new Book();
        book1.setId(1L);
        book1.setTitle("Book One");

        Book book2 = new Book();
        book2.setId(2L);
        book2.setTitle("Book Two");

        Mockito.when(bookService.findAll()).thenReturn(Arrays.asList(book1, book2));

        mockMvc.perform(get("/api/books"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].title", is("Book One")))
                .andExpect(jsonPath("$[1].title", is("Book Two")));
    }

    @Test
    public void shouldReturnBookById() throws Exception {
        Book book = new Book();
        book.setId(1L);
        book.setTitle("Book One");

        Mockito.when(bookService.findById(1L)).thenReturn(Optional.of(book));

        mockMvc.perform(get("/api/books/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title", is("Book One")));
    }

    @Test
    public void shouldCreateBook() throws Exception {
        Book book = new Book();
        book.setId(1L);
        book.setTitle("Book One");

        Mockito.when(bookService.save(any(Book.class))).thenReturn(book);

        mockMvc.perform(post("/api/books")
                .contentType("application/json")
                .content("{\"title\":\"Book One\",\"author\":\"Author One\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title", is("Book One")));
    }

    @Test
    public void shouldUpdateBook() throws Exception {
        Book book = new Book();
        book.setId(1L);
        book.setTitle("Updated Book");

        Mockito.when(bookService.update(eq(1L), any(Book.class))).thenReturn(Optional.of(book));

        mockMvc.perform(put("/api/books/1")
                .contentType("application/json")
                .content("{\"title\":\"Updated Book\",\"author\":\"Updated Author\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title", is("Updated Book")));
    }

    @Test
    public void shouldDeleteBook() throws Exception {
        Mockito.when(bookService.delete(1L)).thenReturn(true);

        mockMvc.perform(delete("/api/books/1"))
                .andExpect(status().isOk());
    }

    public void shouldReturnBadRequestWhenTitleIsMissing() throws Exception {
        String bookJson = "{\"author\":\"Author Name\",\"isbn\":\"1234567890123\"}";

        mockMvc.perform(post("/api/books")
                .contentType("application/json")
                .content(bookJson))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.title").value("Title is mandatory"));
    }

    @Test
    public void shouldReturnBadRequestWhenIsbnTooLong() throws Exception {
        String bookJson = "{\"title\":\"Book Title\",\"author\":\"Author Name\",\"isbn\":\"12345678901234\"}";

        mockMvc.perform(post("/api/books")
                .contentType("application/json")
                .content(bookJson))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.isbn").value("ISBN must be 13 characters or less"));
    }

}
