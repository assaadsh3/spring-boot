package com.lms.lms.servicesTest;
import com.lms.lms.entities.Book;
import com.lms.lms.repositories.BookRepository;
import com.lms.lms.services.BookService;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

public class BookServiceTest {

    @Mock
    private BookRepository bookRepository;

    @InjectMocks
    private BookService bookService;

    public BookServiceTest() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testFindAll() {
        // Arrange
        Book book1 = new Book();
        book1.setTitle("Book One");
        Book book2 = new Book();
        book2.setTitle("Book Two");
        List<Book> books = Arrays.asList(book1, book2);

        when(bookRepository.findAll()).thenReturn(books);

        // Act
        List<Book> result = bookService.findAll();

        // Assert
        assertThat(result).hasSize(2).contains(book1, book2);
        verify(bookRepository, times(1)).findAll();
    }

    @Test
    public void testFindById() {
        // Arrange
        Book book = new Book();
        book.setId(1L);
        book.setTitle("Book One");

        when(bookRepository.findById(1L)).thenReturn(Optional.of(book));

        // Act
        Optional<Book> result = bookService.findById(1L);

        // Assert
        assertThat(result).isPresent();
        assertThat(result.get().getTitle()).isEqualTo("Book One");
        verify(bookRepository, times(1)).findById(1L);
    }

    @Test
    public void testSave() {
        // Arrange
        Book book = new Book();
        book.setTitle("New Book");

        when(bookRepository.save(book)).thenReturn(book);

        // Act
        Book result = bookService.save(book);

        // Assert
        assertThat(result.getTitle()).isEqualTo("New Book");
        verify(bookRepository, times(1)).save(book);
    }

    @Test
    public void testUpdate() {
        // Arrange
        Book existingBook = new Book();
        existingBook.setId(1L);
        existingBook.setTitle("Old Title");

        Book newBookDetails = new Book();
        newBookDetails.setTitle("New Title");

        when(bookRepository.findById(1L)).thenReturn(Optional.of(existingBook));
        when(bookRepository.save(existingBook)).thenReturn(existingBook);

        // Act
        Optional<Book> result = bookService.update(1L, newBookDetails);

        // Assert
        assertThat(result).isPresent();
        assertThat(result.get().getTitle()).isEqualTo("New Title");
        verify(bookRepository, times(1)).findById(1L);
        verify(bookRepository, times(1)).save(existingBook);
    }

    @Test
    public void testDelete() {
        // Arrange
        when(bookRepository.existsById(1L)).thenReturn(true);

        // Act
        boolean result = bookService.delete(1L);

        // Assert
        assertThat(result).isTrue();
        verify(bookRepository, times(1)).existsById(1L);
        verify(bookRepository, times(1)).deleteById(1L);
    }
}
